function downloadResume() {
  const link = document.createElement('a');
  link.href = 'Shrutika_Ikhar_Resume.pdf';
  link.download = 'Shrutika_Ikhar_Resume.pdf';
  link.click();
}
